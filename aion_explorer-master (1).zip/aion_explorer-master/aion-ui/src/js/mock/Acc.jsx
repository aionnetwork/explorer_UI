const Acc = 
{
  content:[
    {  
  		address: "994988c2f588bb8b5858772f7be2d3e83b74e4674a30b724d1f78319edaf3bc1",
  		balance: "0x7abc35b280f9e7406b2",
  		blockNumber: 550724,
  		nonce: "0x10"	
    }
  ]
}

export default Acc;

