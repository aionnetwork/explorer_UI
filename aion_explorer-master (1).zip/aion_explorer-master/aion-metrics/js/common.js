var BASE_API = "https://metrics0-api.aion.network/aion";

var TS_START = 1516683600;
var TS_END = moment().unix();