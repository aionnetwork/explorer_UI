# Aion Explorer Metrics Frontend - POC

This is a WIP proof of concept (POC) for a front-end to the Aion Metrics Service backend, which serves time-series data that has been processed and transformed for consumption by in-browser graph rendering software like highcharts. 

This POC uses the open-source distribution of Highcharts and Highstock to render 3 different multi-resolution, large-sample time series graphs. 
